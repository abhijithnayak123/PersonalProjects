﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MGI.Channel.DMS.Server.Data;
using MGI.Channel.DMS.Server.Impl;
using MGI.Channel.DMS.Server.Contract;

using NUnit.Framework;

using Spring.Context;
using Spring.Context.Support;
using MGI.Channel.Shared.Server.Data;
using Spring.Testing.NUnit;

namespace MGI.Channel.DMS.Server.Test
{
    [TestFixture]
    public class BillPayTest : AbstractTransactionalSpringContextTests
    {

        Dictionary<string, object> context = new Dictionary<string, object>();
        private static string DESKTOP_ENGINE = "DesktopEngine";

        protected override string[] ConfigLocations
        {
            get { return new string[] { "assembly://MGI.Integration.Test/MGI.Integration.Test/hibernate.cfg.xml" }; }

        }

        IDesktopService DeskTopTest { get; set; }
        [SetUp]
        public void Setup()
        {
            IApplicationContext ctx = Spring.Context.Support.ContextRegistry.GetContext();
            DeskTopTest = (IDesktopService)ctx.GetObject(DESKTOP_ENGINE);
        }

        [Test]
        public void CreateBillPayTest()
        {
            var agentsso = new AgentSSO();
            agentsso.UserName = "testagent";
            agentsso.Role = new UserRole();
            agentsso.Role.Id = 1;
            AgentSession session = DeskTopTest.AuthenticateSSO(agentsso, "34", "TCF", context);
            CustomerAuthentication customer = new CustomerAuthentication();
            customer.AlloyID = 1000000000000160;
            CustomerSession customerSession = DeskTopTest.InitiateCustomerSession(Convert.ToInt64(session.SessionId), customer, context);
            MoneyOrderPurchase moneyOrderPurchase = new MoneyOrderPurchase()
            {
                Amount = 100,
                Fee = 10,
                IsSystemApplied = false
            };

            var product = DeskTopTest.GetBillerByName(long.Parse(customerSession.CustomerSessionId), 34,"test", context);
            // var location = DeskTopTest.GetLocations(long.Parse(customerSession.CustomerSessionId),"test","12345")
            BillPayment bp = new BillPayment
            {
                PaymentAmount = 100,
				Fee = 10,
				BillerName = "test",
				AccountNumber = "12345"
            };
            DeskTopTest.ValidateBillPayment(long.Parse(customerSession.CustomerSessionId), bp, context);
            DeskTopTest.AddBillPay(long.Parse(customerSession.CustomerSessionId), product.Id, context);
            //DeskTopTest.Checkout()
          
        }
    }
}