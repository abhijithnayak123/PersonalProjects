﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using MGI.Channel.DMS.Server.Data;
using MGI.Channel.DMS.Server.Impl;
using MGI.Channel.DMS.Server.Contract;

using NUnit.Framework;

using Spring.Context;
using Spring.Context.Support;
using MGI.Channel.Shared.Server.Data;
using Spring.Testing.NUnit;

namespace MGI.Channel.DMS.Server.Test
{
    [TestFixture]
    public class MoneyOrderTest : AbstractTransactionalSpringContextTests
    {

        Dictionary<string, object> context = new Dictionary<string, object>();
        private static string DESKTOP_ENGINE = "DesktopEngine";

        protected override string[] ConfigLocations
        {
            get { return new string[] { "assembly://MGI.Integration.Test/MGI.Integration.Test/hibernate.cfg.xml" }; }

        }

        IDesktopService DeskTopTest { get; set; }
        [SetUp]
        public void Setup()
        {
            IApplicationContext ctx = Spring.Context.Support.ContextRegistry.GetContext();
            DeskTopTest = (IDesktopService)ctx.GetObject(DESKTOP_ENGINE);
        }

        [Test]
        public void CreateMoneyOrderTest()
        {
            var agentsso = new AgentSSO();
            agentsso.UserName = "testagent";
            agentsso.Role = new UserRole();
            agentsso.Role.Id = 1;
            AgentSession session = DeskTopTest.AuthenticateSSO(agentsso, "28", "Carver", context);
            CustomerAuthentication customer = new CustomerAuthentication();
            customer.AlloyID = 1000000000000010;
            context = DeskTopTest.GetContextFromSession(long.Parse(session.SessionId), context);
            CustomerSession customerSession = DeskTopTest.InitiateCustomerSession(Convert.ToInt64(session.SessionId), customer, context);
            MoneyOrderPurchase moneyOrderPurchase = new MoneyOrderPurchase()
            {
                Amount = 100,
                Fee = 10,
                IsSystemApplied = true
            };

            MoneyOrder moneyOrder = DeskTopTest.PurchaseMoneyOrder(long.Parse(customerSession.CustomerSessionId), moneyOrderPurchase, context);
            var cart  = DeskTopTest.ShoppingCart(long.Parse(customerSession.CustomerSessionId), context);
            //DeskTopTest.AddMoneyOrder(long.Parse(customerSession.CustomerSessionId), long.Parse(moneyOrder.Id), context);
            var status = DeskTopTest.Checkout(long.Parse(customerSession.CustomerSessionId), 110, 110, 0, "", ShoppingCartCheckoutStatus.InitialCheckout, context);
            //  DeskTopTest.Checkout();
        }
    }
}